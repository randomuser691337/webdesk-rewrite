export var name = "Settings";
var win;
var core2;
var resizeObserver;
export async function launch(UI, fs, core, unused, module) {
    core2 = core;
    const check = await fs.read('/tmp/settings-open');
    if (check) {
        win = check;
        win.focusWindow();
        core2.removeModule(id);
        return;
    }
    win = UI.window(name, module, undefined, '/apps/Settings.app/icon.svg');
    fs.write('/tmp/settings-open', win);
    console.log(window.outerWidth);
    if (window.outerWidth < 470) {
        win.win.style.width = window.outerWidth / 1.08 + "px";
    } else {
        win.win.style.width = "540px";
    }

    win.win.style.height = "540px";
    win.headertxt.innerHTML = "";
    win.content.style.padding = "0px";
    win.content.style.display = "flex";
    let showSideBar;
    const sidebar = UI.create('div', win.content, 'window-split-sidebar');
    sidebar.style.width = "175px";
    const sidebarWinBtnDiv = UI.create('div', sidebar);
    sidebar.appendChild(win.header);
    win.header.classList.add('window-header-clear');
    win.header.style.padding = "14px";
    win.header.style.paddingBottom = "4px";
    const sidebarcontent = UI.create('div', sidebar, 'content');
    sidebarcontent.style.paddingTop = "0px";

    const accountDiv = UI.create('div', sidebarcontent, 'box-group');
    accountDiv.style.marginTop = "6px";
    const userBar = UI.leftRightLayout(accountDiv);
    userBar.left.innerHTML = `<span class="bold">${UI.userName}</span>`;
    const manageBtn = UI.button(userBar.right, '⚙️', 'ui-small-btn');
    manageBtn.addEventListener('click', function () {
        userAcc();
    });

    const generalButton = UI.button(sidebarcontent, 'General', 'ui-med-btn wide');
    generalButton.addEventListener('click', function () {
        General();
    });

    const personalizeButton = UI.button(sidebarcontent, 'Personalize', 'ui-med-btn wide');
    personalizeButton.addEventListener('click', function () {
        Personalize();
    });

    const llmButton = UI.button(sidebarcontent, 'Manage AI', 'ui-med-btn wide');
    llmButton.addEventListener('click', function () {
        Assistant();
    });

    const container = UI.create('div', win.content, 'window-split-content');
    const titleCont = UI.create('div', container, 'window-draggable');
    const title = UI.create('span', titleCont);
    const content = UI.create('div', container);
    content.style.paddingTop = "4px";
    title.classList.add('bold');

    async function getTotalCacheSize(cacheNames) {
        let totalSize = 0;

        for (const name of cacheNames) {
            const cache = await caches.open(name);
            const requests = await cache.keys();

            for (const request of requests) {
                const response = await cache.match(request);
                if (response) {
                    const cloned = response.clone();
                    const buffer = await cloned.arrayBuffer();
                    totalSize += buffer.byteLength;
                }
            }
        }

        return totalSize;
    }

    function eraseWarn() {
        const bg = UI.create('div', document.body, 'blur-bg');
        const menu = UI.create('div', bg, 'cm');
        menu.style.width = "250px";
        UI.img(menu, '/system/lib/img/warn.svg', 'header-img');
        UI.text(menu, `Are you sure you want to erase all data? This can't be undone.`, 'bold');
        UI.text(menu, `Your WebDesk account won't be affected.`);
        const erase = UI.button(menu, 'Erase WebDesk', 'ui-med-btn wide');
        erase.addEventListener('click', function () {
            fs.erase();
        });
        const close = UI.button(menu, 'Cancel', 'ui-med-btn wide');
        close.addEventListener('click', function () {
            UI.remove(bg);
        });
    }

    function userAcc() {
        content.innerHTML = '';
        title.innerText = "WebDesk Account - " + UI.userName;
        const group1 = UI.create('div', content, 'box-group');
        UI.text(group1, "Profile");
        const changeUsername = UI.button(group1, 'Change Username', 'ui-med-btn');

        const group2 = UI.create('div', content, 'box-group');
        UI.text(group2, "Personal");
        const changePw = UI.button(group2, 'Change Password', 'ui-med-btn');
        const requestLogOutAll = UI.button(group2, 'Log out all other WebDesks', 'ui-med-btn');
    }

    async function General() {
        // The lion should not question why group0 comes after group1.
        content.innerHTML = '';
        title.innerText = "General";
        const group1 = UI.create('div', content, 'box-group');
        const appearbar = UI.leftRightLayout(group1);
        appearbar.left.innerHTML = '<span class="smalltxt">Low-end device mode</span>';
        const enableBtn = UI.switch.create(appearbar.right, false);
        if (await set.read('lowend') === 'true') {
            UI.switch.check(enableBtn);
        }

        enableBtn.addEventListener('click', () => {
            if (UI.switch.checked(enableBtn) === false) {
                set.del('lowend');
                UI.System.lowgfxMode(false);
            } else {
                set.write('lowend', 'true');
                UI.System.lowgfxMode(true);
            }
        });

        const group0 = UI.create('div', content, 'box-group');
        const group0bar = UI.leftRightLayout(group0);
        group0bar.left.innerHTML = '<span class="smalltxt">Danger Zone</span>';
        const eraseBtn = UI.button(group0bar.right, 'Erase...', 'ui-med-btn');
        eraseBtn.addEventListener('click', function () {
            eraseWarn();
        });
    }

    async function Assistant() {
        content.innerHTML = '';
        title.innerText = "Manage AI";
        UI.text(content, `AI features are no longer supported or updated`, 'smalltxt');
        if (('gpu' in navigator)) {
            const gpuTest = await UI.System.GPUTest();
            const compatDiv = UI.create('div', content, 'message-box-group');
            if (gpuTest.perfScore < 0.00004) {
                compatDiv.classList.add('good');
                UI.text(compatDiv, `Compatibility`, 'bold');
                UI.text(compatDiv, `You can run anything in the list.`);
            } else if (gpuTest.perfScore < 0.00028) {
                compatDiv.classList.add('good');
                UI.text(compatDiv, `Compatibility`, 'bold');
                UI.text(compatDiv, `Your graphics processor can run big LLMs well.`);
            } else if (gpuTest.perfScore < 0.0012) {
                compatDiv.classList.add('okay');
                UI.text(compatDiv, `Compatibility`, 'bold');
                UI.text(compatDiv, `Your graphics processor can run the default or mid-sized LLMs fine.`);
            } else {
                compatDiv.classList.add('bad');
                UI.text(compatDiv, `Compatibility`, 'bold');
                UI.text(compatDiv, `Your graphics processor can't run LLMs. You should disable AI features.`);
            }
            const group1 = UI.create('div', content, 'box-group');
            const appearbar = UI.leftRightLayout(group1);
            appearbar.left.innerHTML = '<span class="smalltxt">AI features</span>';
            const enableBtn = UI.switch.create(appearbar.right, false);

            if (await set.read('chloe') === 'activated') {
                UI.switch.check(enableBtn);
            }

            let areyousure;

            enableBtn.addEventListener('click', () => {
                if (UI.switch.checked(enableBtn) === true) {
                    UI.remove(areyousure);
                    areyousure = UI.create('div', win.win, 'cm');
                    UI.text(areyousure, 'Are you sure?', 'bold');
                    UI.text(areyousure, 'WebDesk will reboot if you enable AI features.');
                    const yes = UI.button(areyousure, 'Enable', 'ui-med-btn');
                    yes.addEventListener('click', async function () {
                        await set.del('chloe');
                        window.location.reload();
                    });

                    const no = UI.button(areyousure, 'Cancel', 'ui-med-btn');
                    no.addEventListener('click', async function () {
                        UI.switch.uncheck(enableBtn);
                        UI.remove(areyousure);
                    });
                } else {
                    UI.remove(areyousure);
                    areyousure = UI.create('div', win.win, 'cm');
                    UI.text(areyousure, 'Are you sure?', 'bold');
                    UI.text(areyousure, 'WebDesk will reboot if you disable AI features.');
                    const yes = UI.button(areyousure, 'Disable', 'ui-med-btn');
                    yes.addEventListener('click', async function () {
                        await set.del('chloe');
                        window.location.reload();
                    });

                    const no = UI.button(areyousure, 'Cancel', 'ui-med-btn');
                    no.addEventListener('click', async function () {
                        UI.switch.check(enableBtn);
                        UI.remove(areyousure);
                    });
                }
            });

            UI.line(group1);

            const appearbar3 = UI.leftRightLayout(group1);
            let cacheArrays = ['webllm/config', 'webllm/wasm', 'webllm/model'];
            appearbar3.left.innerHTML = `<span class="smalltxt">Calculating size, please wait...</span>`;

            const DELETEBTN = UI.button(appearbar3.right, 'Delete LLMs', 'ui-med-btn');
            DELETEBTN.addEventListener('click', async function () {
                const areyousure = UI.create('div', document.body, 'cm');
                UI.text(areyousure, 'Are you sure?', 'bold');
                UI.text(areyousure, 'WebDesk will reboot once LLMs are deleted. If AI features are on, the default LLM will redownload.');
                const yes = UI.button(areyousure, 'Delete cache', 'ui-med-btn');
                yes.addEventListener('click', async function () {
                    for (const cacheName of cacheArrays) {
                        const deleted = await caches.delete(cacheName);
                        console.log(`Cache "${cacheName}" deleted:`, deleted);
                    }

                    set.del('LLMModel');
                    window.location.reload();
                });

                const no = UI.button(areyousure, 'Cancel', 'ui-med-btn');
                no.addEventListener('click', async function () {
                    UI.remove(areyousure);
                });
            });

            const group2 = UI.create('div', content, 'box-group');
            const appearbar2 = UI.leftRightLayout(group2);
            appearbar2.left.innerHTML = '<span class="smalltxt">LLM to use</span>';
            let modeln = await set.read('LLMModel');
            if (modeln === undefined) modeln = "Qwen2.5-3B-Instruct-q4f32_1-MLC";
            const dropBtn = UI.button(appearbar2.right, UI.truncate(modeln, 25), 'ui-med-btn wide');
            dropBtn.dropBtnDecor();

            let menu;
            dropBtn.addEventListener('mousedown', async function () {
                const rect = dropBtn.getBoundingClientRect();
                const event = {
                    clientX: Math.floor(rect.left),
                    clientY: Math.floor(rect.bottom)
                };
                UI.remove(menu);
                menu = UI.rightClickMenu(event);
                menu.style.width = `${Math.floor(rect.width) - 10}px`;
                if (sys.LLMLoaded === false) {
                    UI.text(menu, 'Enable AI features to choose LLMs.', 'smalltxt');
                } else {
                    menu.style.height = "350px";
                    const models = sys.LLM.listModels();
                    const btn2 = UI.button(menu, 'Default', 'ui-small-btn wide');

                    let alreadyTriggered = false;

                    function defaultLLM() {
                        const rebootmsg = UI.create('div', document.body, 'cm');
                        UI.text(rebootmsg, 'Use the default model? WebDesk will restart.', 'bold');
                        const match = model.match(/(\d+(?:\.\d+)?)B/i);
                        const size = match ? parseFloat(match[1]) : 0;

                        UI.text(rebootmsg, `This is a mid-sized model. It can handle most tasks with careful prompting, but low-end graphics processors may struggle.`);

                        UI.text(rebootmsg, `Each model acts differently.`);

                        UI.text(rebootmsg, UI.LLMName + ' will restart and use the new model from now on.');

                        const reboot = UI.button(rebootmsg, 'Restart and use model', 'ui-med-btn');
                        reboot.addEventListener('click', async function () {
                            await set.write('LLMModel', 'Qwen2.5-3B-Instruct-q4f32_1-MLC');
                            window.location.reload();
                        });

                        const close = UI.button(rebootmsg, `Cancel`, 'ui-med-btn');
                        close.addEventListener('click', function () {
                            UI.remove(rebootmsg);
                        });
                    }

                    btn2.addEventListener('click', async function () {
                        if (alreadyTriggered) {
                            defaultLLM();
                            alreadyTriggered = true;
                        }
                    });

                    btn2.addEventListener('mouseup', async function () {
                        if (alreadyTriggered) {
                            defaultLLM();
                            alreadyTriggered = true;
                        }
                    });

                    models.forEach(function (model) {
                        if (model.toLowerCase().includes("chat") || model.toLowerCase().includes("instruct")) {
                            const btn = UI.button(menu, model, 'ui-small-btn wide');
                            btn.addEventListener('click', function () {
                                const rebootmsg = UI.create('div', document.body, 'cm');
                                UI.text(rebootmsg, 'Use this model? WebDesk will restart.', 'bold');
                                const match = model.match(/(\d+(?:\.\d+)?)B/i);
                                const size = match ? parseFloat(match[1]) : 0;

                                if (size < 1.1) {
                                    UI.text(rebootmsg, `This model has limited knowledge and might struggle with complex tasks. It runs well on most graphics processors.`);
                                } else if (size > 5.1) {
                                    UI.text(rebootmsg, `THIS MODEL IS HUGE. It'll do nearly everything but requires a high-end graphics processor to run smoothly.`);
                                } else {
                                    UI.text(rebootmsg, `This is a mid-sized model. It can handle most tasks with careful prompting, but low-end graphics processors may struggle.`);
                                }
                                UI.text(rebootmsg, `Each model acts differently.`);

                                UI.text(rebootmsg, UI.LLMName + ' will restart and use the new model from now on.');

                                const reboot = UI.button(rebootmsg, 'Restart and use model', 'ui-med-btn');
                                reboot.addEventListener('click', async function () {
                                    await set.write('LLMModel', model);
                                    window.location.reload();
                                });

                                const close = UI.button(rebootmsg, `Cancel`, 'ui-med-btn');
                                close.addEventListener('click', function () {
                                    UI.remove(rebootmsg);
                                });
                            });
                        }
                    });
                }
            });

            UI.line(group2);

            const appearbar4 = UI.leftRightLayout(group2);
            appearbar4.left.innerHTML = `<span class="smalltxt">BE CAREFUL</span>`;

            const changePrompt = UI.button(appearbar4.right, 'Change Prompt', 'ui-med-btn');
            changePrompt.addEventListener('click', async function () {
                const code = await fs.read('/apps/TextEdit.app/index.js');
                const mod = await core.loadModule(code);
                const textedit = await mod.launch(UI, fs);
                textedit.open('/system/llm/prompt.txt');
            });

            UI.text(content, `Qwen2.5-3B-Instruct-q4f32_1-MLC has the best balance of knowledge and performance, and runs okay on medium-high end devices.`, 'smalltxt');

            await getTotalCacheSize(cacheArrays)
                .then(sizeBytes => {
                    const cacheSizeGB = (sizeBytes / (1024 ** 3)).toFixed(2);
                    appearbar3.left.innerHTML = `<span class="smalltxt">Installed LLMs: ${cacheSizeGB} GB</span>`;
                });
        } else {
            UI.text(content, `Your browser doesn't support WebGPU, so no AI features can be used.`);
            UI.text(content, `Use Chrome/a Chrome-based browser to enable AI features.`);
        }
    }

    function Personalize() {
        content.innerHTML = '';
        title.innerText = "Personalization";
        const group1 = UI.create('div', content, 'box-group');
        const appearbar = UI.leftRightLayout(group1);
        appearbar.left.innerHTML = '<span class="smalltxt">Appearance</span>';

        const lightBtn = UI.button(appearbar.right, 'Light', 'ui-med-btn');
        lightBtn.addEventListener('click', () => {
            UI.System.lightMode();
            set.write('appearance', 'light');
        });
        const darkBtn = UI.button(appearbar.right, 'Dark', 'ui-med-btn');
        darkBtn.addEventListener('click', () => {
            UI.System.darkMode();
            set.write('appearance', 'dark');
        });

        const autoBtn = UI.button(appearbar.right, 'Auto', 'ui-med-btn');
        autoBtn.addEventListener('click', () => {
            const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");
            if (prefersDarkScheme.matches) {
                UI.System.darkMode();
            } else {
                UI.System.lightMode();
            }
            set.write('appearance', 'auto');
        });

        UI.line(group1);

        const accentbar = UI.leftRightLayout(group1);
        accentbar.left.innerHTML = '<span class="smalltxt">Accent color</span>';
        // Accent color buttons based off https://developer.apple.com/design/human-interface-guidelines/color
        const colors = [
            '175,82,222',   // Purple
            '0,122,255',   // Blue
            '90,200,250',  // Light Blue
            '52,199,89',   // Green
            '255,204,0',   // Yellow
            '255,149,0',   // Orange
            '255,45,85',   // Red
        ];

        colors.forEach(color => {
            const colorButton = UI.button(accentbar.right, '', 'accent-button');
            colorButton.style.backgroundColor = "rgb(" + color + ")";
            colorButton.addEventListener('click', () => {
                UI.changevar('ui-accent', color);
                set.write('accent', color);
            });
        });

        const group2 = UI.create('div', content, 'box-group');
        const group2bar = UI.leftRightLayout(group2);
        group2bar.left.innerHTML = '<span class="smalltxt">Wallpaper</span>';

        const randomBlobWall = UI.button(group2bar.right, 'Use dynamic', 'ui-med-btn');
        randomBlobWall.addEventListener('click', function () {
            UI.System.generateBlobWallpaper();
        });

        const uploadWall = UI.button(group2bar.right, 'Upload', 'ui-med-btn');
        uploadWall.addEventListener('click', function () {
            UI.System.generateBlobWallpaper();
        });
    }

    let claustrophobic = false;

    function DynamicResize() {
        if (win.win.style.width < "450px") {
            if (claustrophobic === false) {
                claustrophobic = true;
                UI.menuSlide(sidebar, "setup");
                UI.menuSlide(sidebar, false);
                container.style.transition = "background 0.25s ease-in-out";
                container.style.backgroundColor = "rgba(0, 0, 0, 0)";
                setTimeout(function () {
                    win.win.appendChild(win.header);
                    win.win.appendChild(win.content);
                    win.header.classList.remove('window-header-clear');
                    win.header.style.padding = "10px";
                    win.headertxt.appendChild(title);
                    showSideBar = UI.button(win.headertxt, '☰', 'ui-med-btn');
                    showSideBar.style.marginLeft = "5px";
                    sidebar.classList.add('sidebar-compacted');
                    showSideBar.addEventListener('click', () => {
                        UI.menuSlide(sidebar);
                    });
                }, 250);
            }
        } else {
            if (claustrophobic === true) {
                claustrophobic = false;
                sidebar.classList.remove('sidebar-compacted');
                win.header.classList.add('window-header-clear');
                win.header.style.padding = "14px";
                win.header.style.paddingBottom = "4px";
                sidebar.style.display = "inline-block";
                UI.remove(showSideBar);
                titleCont.appendChild(title);
                sidebarWinBtnDiv.appendChild(win.header);
                container.style.backgroundColor = "rgba(var(--ui-primary), 1.0)";
                UI.menuSlide(sidebar, true);
                setTimeout(function () {
                    UI.menuSlide(sidebar, "stop");
                }, 250);
            }
        }
    }

    resizeObserver = new ResizeObserver(() => {
        DynamicResize();
    });

    resizeObserver.observe(win.win);

    win.updateWindow();
    DynamicResize();
    General();

    return {
        General: General,
        Assistant: Assistant,
        Personalize: Personalize,
        DynamicResize: DynamicResize,
    };
}

export async function close() {
    fs.rm('/tmp/settings-open');
    core2.removeModule(id);
    resizeObserver.unobserve(win.win);
    win.closeWin();
    win = undefined;
}