wd.loadscript('/desk/system/Desktop.app/desktop.js').then(() => {
    console.log("<i> Desktop loaded");
});