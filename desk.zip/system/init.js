Scripts.loadCSS('/system/style.css');
Scripts.loadJS('/system/core.js');
Scripts.loadJS('/system/Desktop.app/index.js');