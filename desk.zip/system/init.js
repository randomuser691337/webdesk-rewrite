Scripts.loadCSS('/system/style.css');
Scripts.loadJS('/system/Desktop.app/index.js');